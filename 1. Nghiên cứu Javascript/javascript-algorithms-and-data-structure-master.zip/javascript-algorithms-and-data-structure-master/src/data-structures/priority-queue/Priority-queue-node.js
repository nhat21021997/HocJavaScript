// Each Node has a value and a priority.

module.exports = class PriorityQueueNode {
  constructor(value, priority) {
    this.value = value;
    this.priority = priority;
  }
};
