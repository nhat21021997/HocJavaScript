## What is recursion?

A process (a function in our case) that calls itself.

## Lecture Node

https://cs.slides.com/colt_steele/searching-algorithms-22#/