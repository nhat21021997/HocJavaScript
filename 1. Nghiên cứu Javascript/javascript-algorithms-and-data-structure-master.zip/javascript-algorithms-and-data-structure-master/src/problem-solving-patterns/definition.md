# Lecture Node

https://cs.slides.com/colt_steele/problem-solving-patterns#/