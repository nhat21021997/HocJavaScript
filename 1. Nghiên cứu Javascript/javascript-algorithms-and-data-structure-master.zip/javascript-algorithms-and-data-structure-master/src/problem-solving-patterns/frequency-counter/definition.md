# FREQUENCY COUNTERS

This pattern uses objects or sets to collect values/frequencies of values.

This can often avoid the need for nested loops or O(N^2) operations with arrays / strings.