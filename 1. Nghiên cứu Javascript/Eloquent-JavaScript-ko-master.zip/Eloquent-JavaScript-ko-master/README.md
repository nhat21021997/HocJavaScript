# 유창한 자바스크립트(Eloquent JavaScript)

유창한 자바스크립트(http://eloquentjavascript.net) 제2 빌드를 위한 소스입니다.

이슈제기와 풀 리퀘스트를 통한 피드백을 환영합니다.

## 빌드 방법

    npm install --production
    apt-get install asciidoc inkscape calibre
    make html

OSX 사용자는, `port`또는 `brew`로 asciidoc package를 설치할 수 있습니다.

PDF 빌드:

    apt-get install texlive texlive-xetex texlive-fonts-extra
    make book.pdf

ePub book 빌드:
  
  make book.epub

epub book에서 mobi book으로 :

    make book.mobi
    
## 번역
