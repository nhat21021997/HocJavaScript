for (var line = "#"; line.length < 8; line += "#")
  console.log(line);
