---
name: 🐛 Bug report
about: 오타 또는 잘못된 링크를 수정 🛠️
---

## Description
